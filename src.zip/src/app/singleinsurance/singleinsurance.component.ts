import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-singleinsurance',
  templateUrl: './singleinsurance.component.html',
  styleUrls: ['./singleinsurance.component.css']
})
export class SingleinsuranceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
