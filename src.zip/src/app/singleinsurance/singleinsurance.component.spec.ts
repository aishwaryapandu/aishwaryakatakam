import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleinsuranceComponent } from './singleinsurance.component';

describe('SingleinsuranceComponent', () => {
  let component: SingleinsuranceComponent;
  let fixture: ComponentFixture<SingleinsuranceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SingleinsuranceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleinsuranceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
