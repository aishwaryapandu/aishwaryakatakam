import { Component, OnInit } from '@angular/core';
import { HttpclientService, Employee, Buynow } from '../httpclient.service';

@Component({
  selector: 'app-employee-register',
  templateUrl: './employee-register.component.html',
  styleUrls: ['./employee-register.component.css']
})
export class BuynowComponent implements OnInit {
  buynow: Buynow = new Buynow('', '', '', '', '', '',);

  constructor(  private httpClientService: HttpclientService) { }

  ngOnInit(): void {
    this. buynow = new Buynow('', '', '', '', '', '',);

  }


  createBuynow(): void {
    this.buynow.buynowid = 'MBMLA' + this.buynow.phone;

    alert(this.buynow.buynowid);
    this.httpClientService.createBuynow(this.buynow)
        .subscribe( data => {
          this. buynow = new Buynow('', '', '', '', '', '',);

          alert('buynow Id =' + data.buynowid + ' your account created successfully. remember this employee ID');
          console.log('buynow' + data);
        });
      }
        public showCapsWarning = false;

        public VerifyPassword(e: { keyCode: number; }){
          if(e.keyCode>=65 && e.keyCode<=90) 
      {
              this.showCapsWarning = true;
          } else {
            this.showCapsWarning = false;
          }
      }
      public regExp1=/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
      
      public userName: any;
      public msg: any;
      public warn: any;
      public pwd: any ;
      public regExp = /(?=.*[A-Z])\w{4,15}/;
      public pwdStrength='';
      public emailstatus='';
      public min: any;
      public max: any;
      public low: any;
      public high: any;
      public val: any;
      public email: any;
      
      public strengthMeter(min: number,max: number,val: number,low: number,high: number){
        this.min=min;
        this.max=max;
        this.low=low;
        this.high=high;
        this.val=val;
      }
      
      
      
        }
  
  /*
   <select [(ngModel)]="customer.accounttype">
            <option>Savings</option>
            <option>Loan</option>
            <option>Fixed Deposit</option>
          </select>


          createEmployee(): void{
            alert(this.employee.employeename+" has registered for "+this.employee.department+" department")
          }*/
}
