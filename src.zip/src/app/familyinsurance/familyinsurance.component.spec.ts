import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FamilyinsuranceComponent } from './familyinsurance.component';

describe('FamilyinsuranceComponent', () => {
  let component: FamilyinsuranceComponent;
  let fixture: ComponentFixture<FamilyinsuranceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FamilyinsuranceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FamilyinsuranceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
