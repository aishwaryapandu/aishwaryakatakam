import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-familyinsurance',
  templateUrl: './familyinsurance.component.html',
  styleUrls: ['./familyinsurance.component.css']
})
export class FamilyinsuranceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
